const CONFIG = {
    SPEED: 280,
    GRAVITY: 1200,
    JUMP_FORCE: 900,
    PLAYER_SCALE: 0.58,
    DEBUG: false,
    SPLASH_TEXTS: [
        // Game reference
        "Made in 2 weeks",
        "Also try Minecraft",
        "Also try Terraria",
        "I love my medic bag",
        // Programming
        "Hello World!",
        "sqrt(-1) love you",
        "Made with Kaboom.js",
        "GNU\/Linux",
        "Available on itch",
        // I have no idea
        "donute",
        "#icharusisoverparty",
        "moss tastey",
        "made with moss",
        "polygonal?",
        "octagonal!",
        "pongon no gonpon",
        "ROFL LMAO XD LOL",
        "@joshuaclayton",
        "w   H  A      t",
        "atumalaca kkkkkkkkk",
        "How about no?",
        "Antidisestablishmentarianism",
        "such cool, much wow",
        "insert-moyai-emoji",
        "99.9% free of amogus",
        "pongon is sus",
        // Hello to the developers countries
        "Privet!, Rossiya",
        "Hello!, USA",
        "Ola!, Brasil",
        // Music references
        "Guess who's back?",
        "Shady\'s Back.",
        // GD References
        "Woah, it\'s Wulzy",
        "I LOVE TUESDAYS",
        "Soon...",
        "Damnit",
        "Nevermind",
    ]
};

export default CONFIG;