# MossedUP

### Keybinds:
- Left Arrow: Move left 
- Right Arrow: Move Right
- Space: Jump
- V: Use dash

### Changelog for Beta v3.2

- All of the changes from v3.1
- Added a better title screen
- Added a credits scene