const CONFIG = {
    SPEED: 280,
    GRAVITY: 1200,
    JUMP_FORCE: 900,
    PLAYER_SCALE: 0.58,
    DEBUG: false,
    SPLASH_TEXTS: [
        // Game reference
        "Made in 2 weeks",
        "Also try Minecraft",
        "Also try Terraria",
        "I love my medic bag",
        "pongon is sus",
        "99.9% free of amogus",
        "octagonal!",
        // Programming
        "Hello World!",
        "sqrt(-1) love you",
        "Made with Kaboom.js",
        "GNU\/Linux",
        "Open Source!",
        "Available on itch.io",
        // I have no idea
        "We have come",
        "donute",
        "#icharusisoverparty",
        "moss tastey",
        "made with moss",
        "polygonal?",
        "pongon no gonpon",
        "ROFL LMAO XD LOL",
        "@joshuaclayton",
        "w   H  A      t",
        "atumalaca kkkkkkkkk",
        "How about no?",
        "Antidisestablishmentarianism",
        "such cool, much wow",
        "insert-moyai-emoji",
        // Hello to the developers countries
        "Privet!, Rossiya",
        "Hello!, USA",
        "Ola!, Brasil",
        // Music references
        "Guess who's back?",
        "Shady\'s Back.",
        // GD References
        "Woah, it\'s Wulzy",
        "I LOVE TUESDAYS",
        "Soon...",
        "Damnit",
        "Nevermind",
        "Balls",
    ]
};

export default CONFIG;